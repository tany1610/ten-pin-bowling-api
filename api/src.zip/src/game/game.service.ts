import { Injectable } from '@nestjs/common';

import { Frame } from './models/frame.model';

@Injectable()
export class GameService {
    private frames: Frame[];
    private gameStorage: Frame[][];
    private bonusRolls: number = 0;
    private bonusRollsLeft: number = 0;
    private maxPins: number = 10;
    private maxFrames: number = 10;

    constructor() {
        this.frames = [];
        this.gameStorage = [];
    }

    private getRandomPins(maxPins: number): number {
        return Math.floor(Math.random() * (maxPins + 1));
    }

    private restartGame(): void {
        this.gameStorage.push(this.frames);
        this.frames = [];
        this.bonusRolls = 0;
        this.bonusRollsLeft = 0;
    }

    private checkForBonusRolls(currentFrame: Frame): void {
        if (this.frames.length + 1 === this.maxFrames && currentFrame.getIsStrike()) {
            this.bonusRolls = 2;
            this.bonusRollsLeft = 2;
        }

        if (this.frames.length + 1 === this.maxFrames && currentFrame.getIsSpare()) {
            this.bonusRolls = 1;
            this.bonusRollsLeft = 1;
        }
    }

    private reduceBonusRollsLeft () : void {
        this.bonusRollsLeft -= 1;
    }

    private proceedGame(frame: Frame): void {
        if (this.frames.length + 1 > this.maxFrames + this.bonusRolls) {
            this.restartGame();
        }

        this.frames.push(frame);
    }


    public roll() : Frame[] {
        if (this.bonusRollsLeft) {
            // Handling bonus rolls
            const firstRollPins = this.getRandomPins(this.maxPins);
            const frame = new Frame(firstRollPins, 0);

            this.reduceBonusRollsLeft();
            this.proceedGame(frame);
        } else {
            // Handling standard roll
            const firstRollPins = this.getRandomPins(this.maxPins);
            const secondRollPins = this.getRandomPins(this.maxPins - firstRollPins);
            const frame = new Frame(firstRollPins, secondRollPins);
    
            this.checkForBonusRolls(frame);
            this.proceedGame(frame);
        }

        return this.frames;
    }

    public getCurrentGameScore(): number {
        let score = 0;

        for (let i = 0; i < this.maxFrames; i++) {
            const frame = this.frames[i];
            
            // Add the current frame's pins
            score += frame.getFirstRoll() + frame.getSecondRoll();

            // Check for spare
            if (frame.getIsSpare()) {
                if (this.frames[i + 1]) {
                    score += this.frames[i + 1].getFirstRoll();
                }
            }

            // Check for strike
            if (frame.getIsStrike()) {
                if (this.frames[i + 1]) {
                    score += this.frames[i + 1].getFirstRoll() + this.frames[i + 1].getSecondRoll();

                    if (this.frames[i + 1].getIsStrike() && this.frames[i + 2]) {
                        // Handle consecutive strikes
                        score += this.frames[i + 2].getFirstRoll();
                    } 
                }
            }
        }

        return score;
    }

    public getGameStorage(): Frame[][]  {
        return this.gameStorage;
    }
}
