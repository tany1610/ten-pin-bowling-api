export class Frame {
    private firstRoll: number;
    private secondRoll: number;
    private isStrike: boolean;
    private isSpare: boolean;

    constructor(firstRoll: number, secondRoll: number) {
        this.firstRoll = firstRoll;
        this.secondRoll = secondRoll;

        if (this.firstRoll === 10) {
            this.isStrike = true;
        } else if (this.firstRoll + this.secondRoll === 10) {
            this.isSpare = true;
        }
    };

    public getIsStrike(): boolean { return  this.isStrike; };
    public getIsSpare(): boolean { return this.isSpare; };
    public getFirstRoll(): number { return this.firstRoll; };
    public getSecondRoll(): number { return this.secondRoll; };
}
