import { Controller, Get, Post } from '@nestjs/common';

import { GameService } from './game.service';
import { Frame } from './models/frame.model';

@Controller('game')
export class GameController {
    constructor(private readonly gameService: GameService) {}

    @Post('/bowl')
    bowl(): Frame[] {
        return this.gameService.roll();
    }

    @Get('/score')
    currentGameScore(): number {
        return this.gameService.getCurrentGameScore();
    }

    @Get('/storage')
    gameStorage(): Frame[][] {
        return this.gameService.getGameStorage();
    }
}
